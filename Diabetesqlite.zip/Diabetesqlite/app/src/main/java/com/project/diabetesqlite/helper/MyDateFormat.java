package com.project.diabetesqlite.helper;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MyDateFormat {

    private static String myFormat = "MMM dd, yyyy";
    private static String myFormatSimple = "yyyy/MM/dd";
    private static String myFormatWithTime = "MMM dd, yyyy HH:mm:ss a";

    public static String getMyDate() {
        return getDateFormat().format(new Date());
    }

    public static String getMyDate(String data) {
        try {
            return getDateFormat().format(Date.parse(data));
        } catch (Exception e) {
            Log.i("DateError", "Cant Convert Date");
            return data;
        }
    }

    public static String getTime12(String time) {
        try {

            final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.US);
            final Date dateObj = sdf.parse(time);
            time = new SimpleDateFormat("hh:mm aa", Locale.US).format(dateObj);
            return time;
        } catch (Exception e) {
            return time;
        }
    }

    public static String getMyDate(Date data) {
        return getDateFormat().format(data);
    }

    public static String getMyDateSimple(Date data) {
        return getDateFormatSimple().format(data);
    }

    public static String getMyDateWithTime() {
        return getDateFormatWithTime().format(new Date());
    }

    private static SimpleDateFormat getDateFormat() {
        return new SimpleDateFormat(myFormat, Locale.US);
    }

    private static SimpleDateFormat getDateFormatSimple() {
        return new SimpleDateFormat(myFormatSimple, Locale.US);
    }

    private static SimpleDateFormat getDateFormatWithTime() {
        return new SimpleDateFormat(myFormatWithTime, Locale.US);
    }
}
