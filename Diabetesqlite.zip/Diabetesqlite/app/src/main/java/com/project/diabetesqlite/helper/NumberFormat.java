package com.project.diabetesqlite.helper;

import java.util.Locale;

public class NumberFormat {

    private static java.text.NumberFormat nf = java.text.NumberFormat.getInstance(Locale.ENGLISH);

    public static String getNumberWithEnglish(int myNumber) {
        return nf.format(myNumber);
    }

}
