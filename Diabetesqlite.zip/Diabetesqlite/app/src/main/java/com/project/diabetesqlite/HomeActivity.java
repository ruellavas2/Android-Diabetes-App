package com.project.diabetesqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;


public class HomeActivity extends AppCompatActivity {
    public Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        button = (Button) findViewById(R.id.btnblood);
        button.setOnClickListener(v -> {
            Intent intent= new Intent(HomeActivity.this,BloodActivity.class);
            startActivity(intent);
        });

        button = (Button) findViewById(R.id.btnmed);
        button.setOnClickListener(v -> {
            Intent intent= new Intent(HomeActivity.this,MedicationActivity.class);
            startActivity(intent);
        });

        button = (Button) findViewById(R.id.btnexcer);
        button.setOnClickListener(v -> {
            Intent intent= new Intent(HomeActivity.this,ExerciseActivity.class);
            startActivity(intent);
        });

        button = (Button) findViewById(R.id.btnbmi);
        button.setOnClickListener(v -> {
            Intent intent= new Intent(HomeActivity.this,BMI.class);
            startActivity(intent);
//
        });

    }
}